# -*- coding: utf-8 -*-
# Example main.py
import re
import argparse
import urllib.request as ur
from bs4 import BeautifulSoup
from PyPDF2 import PdfFileReader, PdfFileWriter
from camelot import read_pdf
import tempfile
import numpy as np

url2 = ("http://normanpd.normanok.gov/content/daily-activity")

def fetchincidents():

    data = ur.urlopen(url2).read()
    soup = BeautifulSoup(data, features="html.parser")
    List = []
    for link in soup.find_all("a", href = re.compile("Arrest")):
        current_link = link.get('href')
        List.append("http://normanpd.normanok.gov" + current_link)
    return List

def extractincidents(List):

    data = ur.urlopen(List[1])
    testfile = ur.URLopener()
    testfile.retrieve(List[1], "file.pdf")

    fp = tempfile.TemporaryFile()
    fp.write(data.read())
    fp.seek(0)

    pdfReader = PdfFileReader(fp)
    page1 = pdfReader.getPage(0).extractText()

    content = ""

    for i in range (0, pdfReader.getNumPages()):
        extractedText = pdfReader.getPage(i).extractText()
        content += extractedText + "\n"

    content = " ".join(content.replace("\xa0", " ").strip().split())

    df = read_pdf("file.pdf", flavor = 'stream', columns=['112,162,241,342,425,465,525,570,599,634,685'],split_text=True)
    
    nadf = df[0].df.replace('',np.nan)
    tocat = np.where(nadf.notna().iloc[:,0])[0]
    for i in tocat[::-1]:
        if (i+1 in df[0].df.index and i-1 in df[0].df.index and nadf.notna().iloc[i+1,0]==False and nadf.notna().iloc[i-1,0]==False):
            df[0].df.iloc[i,:]=df[0].df.iloc[i-1,:]+' '+df[0].df.iloc[i,:]+df[0].df.iloc[i+1,:]
            df[0].df.iloc[i,:]=df[0].df.iloc[i,:].map(lambda x: x.strip())
            df[0].df=df[0].df.drop([i-1,i+1],axis=0)

    df[0].df = df[0].df.reset_index(drop=True)

    nadf = df[0].df.replace('',np.nan)
    tocat = np.where(nadf.notna().iloc[:,0])[0]
    for i in tocat[::-1]:
        if (i+1 in df[0].df.index and i-1 in df[0].df.index and nadf.notna().iloc[i+1,0]==False and nadf.notna().iloc[i-1,0]==False):
            df[0].df.iloc[i,:]=df[0].df.iloc[i-1,:]+' '+df[0].df.iloc[i,:]+' '+df[0].df.iloc[i+1,:]
            df[0].df.iloc[i,:]=df[0].df.iloc[i,:].map(lambda x: x.strip())
            df[0].df=df[0].df.drop([i-1,i+1],axis=0)

    print(df[0].parsing_report)
    df[0].to_csv("file.csv")

    return content

def main(url):
    print(fetchincidents())
    print(extractincidents(fetchincidents()))

    # Download data
#    project0.fetchincidents(url)

    # Extract Data
#    incidents = project0.extractincidents()
	
    # Create Dataase
#    db = project0.createdb()
	
    # Insert Data
#    project0.populatedb(db, incidents)
	
    # Print Status
#    project0.status(db)


if __name__ == '__main__':
    main(url2)
#    parser = argparse.ArgumentParser()
#    parser.add_argument("--arrests", type=str, required=True, 
#                         help="The arrest summary url.")
     
#    args = parser.parse_args()
#    if args.arrests:
#        main(args.arrests)
