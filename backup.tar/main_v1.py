# -*- coding: utf-8 -*-
# Example main.py
import re
import argparse
import urllib.request as ur
from bs4 import BeautifulSoup

url = ("http://normanpd.normanok.gov/filebrowser_download/"
       "657/2019-02-10%20Daily%20Arrest%20Summary.pdf")

data = ur.urlopen(url).read()

def download():

    url2 = ("http://normanpd.normanok.gov/content/daily-activity")
    data = ur.urlopen(url2).read()
    body = data.decode('utf-8')
    match = re.search(r'Incident',body)

    soup = BeautifulSoup(data)
    List = []
    for link in soup.find_all("a", href = re.compile("Incident")):
        current_link = link.get('href')
        print('Got a pdf! ' + current_link)
        List.append(current_link)
    return List


def main(url):
    print(download())

    # Download data
#    project0.fetchincidents(url)

    # Extract Data
#    incidents = project0.extractincidents()
	
    # Create Dataase
#    db = project0.createdb()
	
    # Insert Data
#    project0.populatedb(db, incidents)
	
    # Print Status
#    project0.status(db)


if __name__ == '__main__':
    main(url)
#    parser = argparse.ArgumentParser()
#    parser.add_argument("--arrests", type=str, required=True, 
#                         help="The arrest summary url.")
     
#    args = parser.parse_args()
#    if args.arrests:
#        main(args.arrests)
